//
//  ShowFoodViewController.swift
//  LoginApp
//
//  Created by Link on 2019/10/15.
//  Copyright © 2019 Link. All rights reserved.
//

import UIKit

class ShowFoodViewController: UIViewController {
    
    @IBOutlet weak var nameText: UITextField!
    @IBOutlet weak var descriptionText: UITextField!
    var food: Food?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        nameText.text = food?.foodName
        descriptionText.text = food?.descriptionValue
        // Do any additional setup after loading the view.
    }
    

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
        if (segue.identifier == "cancelToTable") {
            print("cancel save")
        }
        else{
            food = Food(name: nameText.text, descriptionValue: descriptionText.text)
        }
    }
    

}
