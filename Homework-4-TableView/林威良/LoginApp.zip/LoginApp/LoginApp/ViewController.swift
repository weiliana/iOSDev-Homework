//
//  ViewController.swift
//  LoginApp
//
//  Created by Link on 2019/9/24.
//  Copyright © 2019 Link. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var userName: String!
    var userPasswd: String!
    // 程序退出入口，用于其他界面退出后跳转
    @IBAction func exitToSignIn (segue: UIStoryboardSegue) {
        
    }
    
    @IBOutlet weak var flyIcon: UIImageView!
    @IBOutlet weak var welcomeLabel: UILabel!
    @IBOutlet weak var nameText: UITextField!
    @IBOutlet weak var passwdText: UITextField!
    @IBOutlet weak var hintLabel: UILabel!
    @IBOutlet weak var loginButton: UIButton!
    @IBOutlet weak var signUpButton: UIButton!
    @IBOutlet weak var userHeadImage: UIImageView!
    
    @IBAction func loginButtonClick(_ sender: Any) {
        
        switch loginButton.currentTitle {
        case "Sign In":
            // 用户名正确
            if (nameText.text == userName) {
                // 密码正确
                if (passwdText.text == userPasswd) {
                    hintLabel.text = "Sign In Successful!"
                    loginSuccessfully(title: "Welcome  Back! " + userName)
                    loginButton.backgroundColor = UIColor(red: 0.96, green: 0.0, blue: 0.30, alpha: 1.0)
                } else {
                    passwdText.shake()
                    passwdText.text = ""
                    hintLabel.isHidden = false
                    hintLabel.text = "Sign In Failed!\nCheck out your password."
                }
            } else {
                nameText.shake()
                passwdText.shake()
                hintLabel.isHidden = false
                hintLabel.text = "Sign In Failed!\nCheck out your name."
            }
        case "Sign Out":
            initTextField()
            loginButton.backgroundColor = UIColor(red: 0.28, green: 0.26, blue: 1.0, alpha: 1.0)
            welcomeLabel.text = "Welcome  Back!"
            loginButton.setTitle("Sign In", for: .normal)
            signUpButton.setTitle("Don't have account? Sign Up", for: .normal)
            userHeadImage.isHidden = true
            nameText.isHidden = false
            passwdText.isHidden = false
            signUpButton.isHidden = false
        case "Sign Up":
            if (nameText.text != "")&&(passwdText.text != "") {
                userName = nameText.text!
                userPasswd = passwdText.text!
                loginSuccessfully(title: "Welcome! " + userName)
            } else {
                nameText.shake()
                passwdText.shake()
                hintLabel.isHidden = false
                hintLabel.text = "Sign Up Failed!\nCheck out your name and password."
            }
        default: break
            
        }
        
    }
    
    func signUpButtonClick(_ sender: Any) {
        if (signUpButton.currentTitle == "Don't have account? Sign Up") {
            initTextField()
            welcomeLabel.text = "Welcome to\nBearPlay!"
            loginButton.setTitle("Sign Up", for: .normal)
            signUpButton.setTitle("Already have account? Sign In", for: .normal)
            
        } else{
            initTextField()
            welcomeLabel.text = "Welcome  Back!"
            loginButton.setTitle("Sign In", for: .normal)
            signUpButton.setTitle("Don't have account? Sign Up", for: .normal)
        }
    }
    // 初始化输入框
    func initTextField() -> Void {
        nameText.text = ""
        passwdText.text = ""
        hintLabel.text = ""
        hintLabel.isHidden = true
        nameText.becomeFirstResponder()
    }
    // 登录成功
    func loginSuccessfully(title: String) -> Void {
        userHeadImage.shake(direction: .vertical)
        hintLabel.text = "Sign In Successful!"
        welcomeLabel.text = title
        loginButton.setTitle("Sign Out", for: .normal)
        nameText.isHidden = true
        passwdText.isHidden = true
        signUpButton.isHidden = true
        hintLabel.isHidden = false
        userHeadImage.isHidden = false
        playAnimations()
    }
    
    func playAnimations(interval: TimeInterval = 2) -> Void {
        self.flyIcon.isHidden = false
        UIView.animate(withDuration: interval, animations: {
            var transformTranslate = self.flyIcon.transform
            transformTranslate = transformTranslate.translatedBy(x: 400.0, y: -400.0)
            self.flyIcon.transform = transformTranslate
        }) { (complete) in
            UIView.animate(withDuration: interval, animations: {
                self.flyIcon.layer.setAffineTransform(CGAffineTransform.identity)
            })
            self.flyIcon.isHidden = true
        }
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        userName = "link"
        userPasswd = "2019"
        // 设置圆角
        setTextFieldRound(textField: nameText, radius: 24.0)
        // 设置图标
        setTextFieldLeftImage(textField: nameText, imageName: "bear")
        
        setTextFieldRound(textField: passwdText, radius: 24.0)
        setTextFieldLeftImage(textField: passwdText, imageName: "lock")
        
        setButtonRound(button: loginButton, radius: 24.0)
    }
    
    // 设置输入框圆角
    func setTextFieldRound(textField: UITextField, radius: CGFloat) {
        textField.layer.masksToBounds = true
        textField.layer.cornerRadius = radius
    }
    
    // 设置输入框圆角
    func setButtonRound(button: UIButton, radius: CGFloat) {
        button.layer.masksToBounds = true
        button.layer.cornerRadius = radius
    }

    // 设置输入框左侧图标
    func setTextFieldLeftImage(textField: UITextField, imageName:String) {
        textField.leftViewMode = UITextField.ViewMode.always
        // 设置图片视图框，用来存放图片
        let iconImageView = UIImageView()
        iconImageView.image = UIImage(named: imageName)
        iconImageView.frame = CGRect(x: 0, y: 0, width: 28, height: 28)
        iconImageView.contentMode = UIView.ContentMode.scaleToFill
        // 设置左侧视图框
        let leftView = UIView(frame: CGRect(x: 0, y: 0, width: 48, height: 48))
        leftView.addSubview(iconImageView)
        iconImageView.center = leftView.center
        textField.leftView = leftView
    }

}

public enum ShakeDirection: Int
{
    case horizontal, vertical
}

extension UIView
{
    /**
     扩展UIView,增加抖动方法
     Parameters:
     - direction: 抖动方向（默认水平方向）
     - times: 抖动次数（默认5次）
     - interval: 每次抖动时间（默认0.1秒）
     - delta: 抖动偏移量（默认2）
     - completion: 抖动动画结束后的回调
    */
    public func shake(direction: ShakeDirection = .horizontal, times: Int = 5, interval: TimeInterval = 0.1, delta: CGFloat = 2, completion: (() -> Void)? = nil)
    {
        UIView.animate(withDuration: interval, animations: {
            switch direction {
            case .horizontal:
                self.layer.setAffineTransform(CGAffineTransform(translationX: delta, y: 0))
            case .vertical:
                self.layer.setAffineTransform(CGAffineTransform(translationX: 0, y: delta))
            }
        }) { (complete) in
            // 最后一次抖动，将位置重置
            if times == 0 {
                UIView.animate(withDuration: interval, animations: {
                    self.layer.setAffineTransform(CGAffineTransform.identity)
                }, completion: { (complete) in
                    completion?()
                })
            } else {
                self.shake(direction: direction, times: times - 1, interval: interval, delta: -delta, completion: completion)
            }
        }
    }
}
