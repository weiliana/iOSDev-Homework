//
//  ViewController.swift
//  helloworld
//
//  Created by Apple on 2019/9/10.
//  Copyright © 2019 CCCYounger. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var inputUsername: UITextField!
   
    @IBOutlet weak var inputPassword: UITextField!
    
    @IBOutlet weak var welcomeLabel: UILabel!
  
    @IBOutlet weak var hintLabel: UILabel!
    
    
    @IBAction func login(_ sender: Any) {
        if let userName=inputUsername.text{
            welcomeLabel.text="welcome!"+userName
        }
        if((inputUsername.text=="Younger")&&(inputPassword.text=="123456")){
            hintLabel.isHidden=false
            hintLabel.text="login successful"
        }else{
            hintLabel.isHidden=false
            hintLabel.text="login failed,please check your username and password!"
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
         
    }


}

