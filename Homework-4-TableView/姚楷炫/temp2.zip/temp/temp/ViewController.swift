//
//  ViewController.swift
//  temp
//
//  Created by Apple on 2019/9/24.
//  Copyright © 2019 Apple. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var nametext: UITextField!
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var passwordtext: UITextField!
    @IBOutlet weak var login_btn: UIButton!
    @IBOutlet weak var hint_label: UILabel!
    @IBAction func loginButtonClick(_ sender: UIButton) {
        if((nametext.text == "Yao") && (passwordtext.text == "123")){
            hint_label.isHidden = false
            hint_label.text = "login successful"
            self.imageView.backgroundColor = UIColor.white
            imageView.image = UIImage(named:"timg")
        }
        else{
            hint_label.isHidden = false
            hint_label.text = "login failed,please check again"
        }
        
    }
    @IBAction func exitToFere (segue:
        UIStoryboardSegue){
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
}

