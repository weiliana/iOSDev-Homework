//
//  food.swift
//  temp
//
//  Created by Apple on 2019/10/15.
//  Copyright © 2019 Apple. All rights reserved.
//

import Foundation

class food : NSObject, NSCoding{
    var name: String?
    var fooddescription: String?
    //add document path
    static let DocumentsDirectory = FileManager().urls(for: .documentDirectory, in: .userDomainMask).first!
    static let ArchiveURL = DocumentsDirectory.appendingPathComponent("foodlist")
    
    init(name: String?, description: String?){
        self.name = name;
        self.fooddescription = description;
    }
    
    func encode(with aCoder: NSCoder) {
        aCoder.encode(name, forKey: "nameKey")
        aCoder.encode(fooddescription, forKey: "descriptKey")
    }
    
    required init?(coder aDecoder: NSCoder) {
        name = aDecoder.decodeObject(forKey: "nameKey") as? String
        fooddescription = aDecoder.decodeObject(forKey: "descriptKey") as? String
    }
}
