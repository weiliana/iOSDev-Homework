//
//  descriptionViewController.swift
//  temp
//
//  Created by Apple on 2019/10/15.
//  Copyright © 2019 Apple. All rights reserved.
//

import UIKit

class descriptionViewController: UIViewController {

    @IBOutlet weak var nameText: UITextField!
    @IBOutlet weak var descriptionText: UITextField!
    var foodForEdit: food?
    override func viewDidLoad() {
        super.viewDidLoad()

        self.nameText.text = foodForEdit?.name
        self.descriptionText.text = foodForEdit?.fooddescription
        self.navigationItem.title = foodForEdit?.name
        // Do any additional setup after loading the view.
    }
    

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
        if segue.identifier == "Save" {
            foodForEdit?.name = nameText.text
            foodForEdit?.fooddescription = descriptionText.text
        }
    }
}
