//
//  NameOfTableViewController.swift
//  HelloWorld
//
//  Created by ASCII on 2019/10/15.
//  Copyright © 2019 ASCII. All rights reserved.
//

import UIKit

class NameOfTableViewController: UIViewController {

    @IBOutlet weak var nameText: UITextField!
    @IBOutlet weak var ageText: UITextField!
    
    var nameForEdit: Name?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.nameText.text = nameForEdit?.name
        self.ageText.text = nameForEdit?.age
        // Do any additional setup after loading the view.
    }
    

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
        if  segue.identifier=="saveToTable"{
            nameForEdit?.name = nameText.text
            nameForEdit?.age = ageText.text
        }
        
    }
    

}
