//
//  File.swift
//  HelloWorld
//
//  Created by ASCII on 2019/10/15.
//  Copyright © 2019 ASCII. All rights reserved.
//

import Foundation

class Name: NSObject, NSCoding {
    func encode(with aCoder: NSCoder) {
        aCoder.encode(name,forKey: "nameKey")
        aCoder.encode(age,forKey: "ageKey")
    }
    
    required init?(coder aDecoder: NSCoder) {
        name = aDecoder.decodeObject(forKey: "nameKey") as? String
        age = aDecoder.decodeObject(forKey: "ageKey") as? String
    }
    
    
    var name: String?
    var age: String?
    
    init(_name:String? , _age: String?) {
        name = _name
        age = _age
    }
    
    static let DocumentsDirectory = FileManager().urls(for: .documentDirectory, in: .userDomainMask).first!
    static let ArchiveURL = DocumentsDirectory.appendingPathComponent("nameList")
    
    
}



