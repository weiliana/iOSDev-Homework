//
//  ViewController.swift
//  HelloWorld
//
//  Created by ASCII on 2019/9/10.
//  Copyright © 2019 ASCII. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var comment1: UIStackView!
    @IBOutlet weak var comment2: UIStackView!
    @IBOutlet weak var comment3: UIStackView!
    @IBOutlet weak var comment: UITextField!
    @IBOutlet weak var comLab1: UILabel!
    @IBOutlet weak var comLab2: UILabel!
    @IBOutlet weak var comLab3: UILabel!
    
    
    
    
    
    
    @IBAction func commitOnClick(_ sender: Any) {
        if(comment1.isHidden == true){
            comment1.isHidden = false
            comLab1.text = comment.text
        }
        else if(comment2.isHidden == true){
            comment2.isHidden = false
            comLab2.text = comment.text
        }
        else{
            comment3.isHidden = false
            comLab3.text = comment.text
        }
    }
    
    @IBAction func exitToHere(segue : UIStoryboardSegue){
        
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

